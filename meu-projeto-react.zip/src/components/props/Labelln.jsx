import React from 'react';

export default function Labelln({ texto }) {
  return (
    <>
      {texto} <br />
    </>
  );
}