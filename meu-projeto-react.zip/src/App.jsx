import Login from "./components/props/Login.jsx";

function App() {
  return (
    <>
      <Login />
    </>
  );
}

export default App;